﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PubgMod.Models
{
    public class AppSettings
    {
        public string Apphash { get; set; }
        public bool IsFrozen { get; set; }
        public string UpdateLink { get; set; }
    }
}
